//
//  OpenCV.h
//  NailDesign
//
//  Created by ykwon on 5/2/18.
//  Copyright © 2018 BarbarianGroup. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OpenCV : NSObject

+ (nonnull UIImage *)handFingerDetect:(nonnull UIImage *)image;
+ (nonnull UIImage *)cannyEdgeImage:(nonnull UIImage *)image;
+ (nonnull UIImage *)cvtColorBGR2GRAY:(nonnull UIImage *)image;
+ (nonnull UIImage *)curveSearch:(nonnull UIImage *)image;

@end


