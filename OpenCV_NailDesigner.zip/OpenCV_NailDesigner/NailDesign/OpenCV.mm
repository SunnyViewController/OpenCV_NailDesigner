//
//  OpenCV.m
//  NailDesign
//
//  Created by ykwon on 5/2/18.
//  Copyright © 2018 BarbarianGroup. All rights reserved.
//
#import <vector>
#import <opencv2/opencv.hpp>
#import <opencv2/imgproc.hpp>

#import <Foundation/Foundation.h>
#import "OpenCV.h"

#include <iostream>

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

/// Converts an UIImage to Mat.
/// Orientation of UIImage will be lost.
static void UIImageToMat(UIImage *image, cv::Mat &mat) {
    
    // Create a pixel buffer.
    NSInteger width = CGImageGetWidth(image.CGImage);
    NSInteger height = CGImageGetHeight(image.CGImage);
    CGImageRef imageRef = image.CGImage;
    cv::Mat mat8uc4 = cv::Mat((int)height, (int)width, CV_8UC4);
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGContextRef contextRef = CGBitmapContextCreate(mat8uc4.data, mat8uc4.cols, mat8uc4.rows, 8, mat8uc4.step, colorSpace, kCGImageAlphaPremultipliedLast | kCGBitmapByteOrderDefault);
    CGContextDrawImage(contextRef, CGRectMake(0, 0, width, height), imageRef);
    CGContextRelease(contextRef);
    CGColorSpaceRelease(colorSpace);
    
    // Draw all pixels to the buffer.
    cv::Mat mat8uc3 = cv::Mat((int)width, (int)height, CV_8UC3);
    cv::cvtColor(mat8uc4, mat8uc3, CV_RGBA2BGR);
    
    mat = mat8uc3;
}

/// Converts a Mat to UIImage.
static UIImage *MatToUIImage(cv::Mat &mat) {
    
    // Create a pixel buffer.
    assert(mat.elemSize() == 1 || mat.elemSize() == 3);
    cv::Mat matrgb;
    if (mat.elemSize() == 1) {
        cv::cvtColor(mat, matrgb, CV_GRAY2RGB);
    } else if (mat.elemSize() == 3) {
        cv::cvtColor(mat, matrgb, CV_BGR2RGB);
    }
    
    // Change a image format.
    NSData *data = [NSData dataWithBytes:matrgb.data length:(matrgb.elemSize() * matrgb.total())];
    CGColorSpaceRef colorSpace;
    if (matrgb.elemSize() == 1) {
        colorSpace = CGColorSpaceCreateDeviceGray();
    } else {
        colorSpace = CGColorSpaceCreateDeviceRGB();
    }
    CGDataProviderRef provider = CGDataProviderCreateWithCFData((__bridge CFDataRef)data);
    CGImageRef imageRef = CGImageCreate(matrgb.cols, matrgb.rows, 8, 8 * matrgb.elemSize(), matrgb.step.p[0], colorSpace, kCGImageAlphaNone|kCGBitmapByteOrderDefault, provider, NULL, false, kCGRenderingIntentDefault);
    UIImage *image = [UIImage imageWithCGImage:imageRef];
    CGImageRelease(imageRef);
    CGDataProviderRelease(provider);
    CGColorSpaceRelease(colorSpace);
    
    return image;
}

/// Restore the orientation to image.
static UIImage *RestoreUIImageOrientation(UIImage *processed, UIImage *original) {
    if (processed.imageOrientation == original.imageOrientation) {
        return processed;
    }
    return [UIImage imageWithCGImage:processed.CGImage scale:1.0 orientation:original.imageOrientation];
}

#pragma mark -


@implementation OpenCV

+ (nonnull UIImage *)handFingerDetect:(nonnull UIImage *)image {
    cv::Mat frame;
    UIImageToMat(image, frame);
    
    cv::Mat hsv;
    cv::cvtColor(frame, hsv, CV_BGR2GRAY);
    cv::inRange(hsv, cv::Scalar(160, 160, 160), cv::Scalar(255, 255, 255), hsv);
    
    int blurSize = 5;
    int elementSize = 5;
    cv::medianBlur(hsv, hsv, blurSize);
    cv::Mat element = cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(2 * elementSize + 1, 2 * elementSize + 1), cv::Point(elementSize, elementSize));
    cv::dilate(hsv, hsv, element);
    
    cv::Mat gray, blur, edge;
    if (frame.channels() > 1) {
        cv::cvtColor(frame, gray, CV_RGB2GRAY);
    } else {
        frame.copyTo(gray);
    }
    
    cv::GaussianBlur(gray, blur, cv::Size(5, 5), 3, 3);
    cv::Canny(blur, edge, 5, 5 * 3, 3);
    
    
    std::vector<std::vector<cv::Point> > contours;
    std::vector<cv::Vec4i> hierarchy;
    std::vector<cv::Point> approx, approxCurves;
    
    double area,maxArea=0.0,epsilon;
    cv::findContours(hsv, contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE, cv::Point(0, 0));
    size_t largestContour = 0;
    for (size_t i = 1; i < contours.size(); i++)
    {
        if (cv::contourArea(contours[i]) > cv::contourArea(contours[largestContour]))
            largestContour = i;
    }
    cv::drawContours(edge, contours, largestContour, cv::Scalar(0, 0, 0), CV_FILLED);
    
    cv::findContours(edge, contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE, cv::Point(0, 0));
    
    for (int i = 1; i < contours.size(); i++)
    {
        area = contourArea(contours[i]);
        epsilon = arcLength(contours[i], true)*0.02;
        cv::approxPolyDP(contours[i], approxCurves, epsilon, true);
        //if (cv::contourArea(contours[i]) > cv::contourArea(contours[largestContour]))
        //CV_FILLED && approxCurves.size() == 4 && isContourConvex(cv::Mat(approxCurves))
        if(area > 0 && area < 10000){
            maxArea = area;
            approx = approxCurves;
            cv::drawContours(frame, contours, i, cv::Scalar(0, 0, 255), CV_FILLED);
        }
        
        
    }
    
    UIImage *grayImage = MatToUIImage(frame);
    return RestoreUIImageOrientation(grayImage, image);
}

+ (nonnull UIImage *)cannyEdgeImage:(nonnull UIImage *)image {
    
    cv::Mat mat;
    UIImageToMat(image, mat);
    
    cv::Mat gray, blur, edge;
    if (mat.channels() > 1) {
        cv::cvtColor(mat, gray, CV_RGB2GRAY);
    } else {
        mat.copyTo(gray);
    }
    
    cv::GaussianBlur(gray, blur, cv::Size(5, 5), 3, 3);
    cv::Canny(blur, edge, 15, 15 * 3, 3);
    
    // Contour detection
    std::vector<std::vector<cv::Point> > contours;
    std::vector<cv::Vec4i> hierarchy;
    std::vector<cv::Point> approx, approxCurves;
    
    double area,maxArea=0.0,epsilon;
    cv::findContours(edge, contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE, cv::Point(0, 0));
    
    for (int i = 1; i < contours.size(); i++)
    {
        area = contourArea(contours[i]);
        epsilon = arcLength(contours[i], true)*0.02;
        cv::approxPolyDP(contours[i], approxCurves, epsilon, true);
        //if (cv::contourArea(contours[i]) > cv::contourArea(contours[largestContour]))
        //CV_FILLED && approxCurves.size() == 4 && isContourConvex(cv::Mat(approxCurves))
        if(area > 300 && area > 10000){
            maxArea = area;
            approx = approxCurves;
            cv::drawContours(mat, contours, i, cv::Scalar(0, 0, 255), CV_FILLED);
        }
        
        
    }
    
    UIImage *edgeImg = MatToUIImage(mat);
    return RestoreUIImageOrientation(edgeImg, image);
}

+ (nonnull UIImage *)cvtColorBGR2GRAY:(nonnull UIImage *)image {
    cv::Mat bgrMat;
    UIImageToMat(image, bgrMat);
    cv::Mat grayMat;
    cv::cvtColor(bgrMat, grayMat, CV_BGR2GRAY);
    UIImage *grayImage = MatToUIImage(grayMat);
    return RestoreUIImageOrientation(grayImage, image);
}

+ (nonnull UIImage *)curveSearch:(nonnull UIImage *)image {
    cv::Mat mat;
    UIImageToMat(image, mat);
    
    cv::Mat gray, blur, edge;
    if (mat.channels() > 1) {
        cv::cvtColor(mat, gray, CV_BGR2GRAY);
    } else {
        mat.copyTo(gray);
    }
    
    cv::blur(gray, blur, cv::Size(3, 3));
    cv::Canny(gray, edge, 20, 50);
    
    std::vector<std::vector<cv::Point> > contours;
    std::vector<cv::Vec4i> hierarchy;
    std::vector<cv::Point> approx, approxCurves;
    
    double area,maxArea=0.0,epsilon;
    cv::findContours(edge, contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE, cv::Point(0, 0));
    
    for (int i = 1; i < contours.size(); i++)
    {
        area = contourArea(contours[i]);
        epsilon = arcLength(contours[i], true)*0.02;
        cv::approxPolyDP(contours[i], approxCurves, epsilon, true);
        if (isContourConvex(cv::Mat(approxCurves))) {
            
            drawContours(mat, contours, i, cvScalar(0, 255, 255), CV_FILLED);
        }
    }
    
    UIImage *edgeImg = MatToUIImage(mat);
    return RestoreUIImageOrientation(edgeImg, image);
}

@end
